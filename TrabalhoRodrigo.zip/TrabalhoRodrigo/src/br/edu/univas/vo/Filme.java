package br.edu.univas.vo;

public class Filme  extends Tipo {

}
