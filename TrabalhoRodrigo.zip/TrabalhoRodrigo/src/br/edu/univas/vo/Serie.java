package br.edu.univas.vo;

public class Serie extends Tipo {

}
